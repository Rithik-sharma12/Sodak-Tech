import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, Problem, Submission, UserSetting, Role } from '../types';
import { INITIAL_USER, MOCK_PROBLEMS, MOCK_SUBMISSIONS, DEFAULT_SETTINGS } from '../data/mockData';

interface AppContextType {
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  role: Role;
  setRole: (role: Role) => void;
  isLoggedIn: boolean;
  setIsLoggedIn: (logged: boolean) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedProblemId: string | null;
  setSelectedProblemId: (id: string | null) => void;
  selectedSubmissionId: string | null;
  setSelectedSubmissionId: (id: string | null) => void;
  selectedContestId: string | null;
  setSelectedContestId: (id: string | null) => void;
  problems: Problem[];
  addProblem: (p: Problem) => void;
  updateProblem: (p: Problem) => void;
  deleteProblem: (id: string) => void;
  submissions: Submission[];
  addSubmission: (sub: Submission) => void;
  solvedProblemIds: string[];
  bookmarks: string[];
  toggleBookmark: (problemId: string) => void;
  settings: UserSetting;
  updateSettings: (newSettings: Partial<UserSetting>) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
  searchModalOpen: boolean;
  setSearchModalOpen: (open: boolean) => void;
  editProfileModalOpen: boolean;
  setEditProfileModalOpen: (open: boolean) => void;
  navigateToProblem: (id: string) => void;
  navigateToSubmission: (id: string) => void;
  navigateToContest: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [role, setRoleState] = useState<Role>(INITIAL_USER.role);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedProblemId, setSelectedProblemId] = useState<string | null>('two-sum');
  const [selectedSubmissionId, setSelectedSubmissionId] = useState<string | null>('a3f9c2e1');
  const [selectedContestId, setSelectedContestId] = useState<string | null>('weekly-challenge-142');
  
  const [problems, setProblems] = useState<Problem[]>(MOCK_PROBLEMS);
  const [submissions, setSubmissions] = useState<Submission[]>(MOCK_SUBMISSIONS);
  const [bookmarks, setBookmarks] = useState<string[]>(['two-sum']);
  const [settings, setSettings] = useState<UserSetting>(DEFAULT_SETTINGS);
  const [searchModalOpen, setSearchModalOpen] = useState<boolean>(false);
  const [editProfileModalOpen, setEditProfileModalOpen] = useState<boolean>(false);

  const setRole = (newRole: Role) => {
    setRoleState(newRole);
    setUser(prev => ({ ...prev, role: newRole }));
  };

  const solvedProblemIds = submissions
    .filter(s => s.userId === user.id && s.verdict === 'Accepted')
    .map(s => s.problemId);

  const addProblem = (p: Problem) => {
    setProblems(prev => [p, ...prev]);
  };

  const updateProblem = (p: Problem) => {
    setProblems(prev => prev.map(item => item.id === p.id ? p : item));
  };

  const deleteProblem = (id: string) => {
    setProblems(prev => prev.filter(p => p.id !== id));
  };

  const addSubmission = (sub: Submission) => {
    setSubmissions(prev => [sub, ...prev]);
    if (sub.verdict === 'Accepted' && !solvedProblemIds.includes(sub.problemId)) {
      setUser(prev => ({
        ...prev,
        problemsSolved: {
          ...prev.problemsSolved,
          easy: sub.difficulty === 'Easy' ? prev.problemsSolved.easy + 1 : prev.problemsSolved.easy,
          medium: sub.difficulty === 'Medium' ? prev.problemsSolved.medium + 1 : prev.problemsSolved.medium,
          hard: sub.difficulty === 'Hard' ? prev.problemsSolved.hard + 1 : prev.problemsSolved.hard,
        }
      }));
    }
  };

  const toggleBookmark = (problemId: string) => {
    setBookmarks(prev => 
      prev.includes(problemId) ? prev.filter(id => id !== problemId) : [...prev, problemId]
    );
  };

  const updateSettings = (newSettings: Partial<UserSetting>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const theme = settings.theme || 'light';

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setSettings(prev => ({ ...prev, theme: nextTheme }));
  };

  const setTheme = (newTheme: 'light' | 'dark') => {
    setSettings(prev => ({ ...prev, theme: newTheme }));
  };

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const navigateToProblem = (id: string) => {
    setSelectedProblemId(id);
    setActiveTab('problem-detail');
  };

  const navigateToSubmission = (id: string) => {
    setSelectedSubmissionId(id);
    setActiveTab('submission-detail');
  };

  const navigateToContest = (id: string) => {
    setSelectedContestId(id);
    setActiveTab('contest-detail');
  };

  // Global Cmd+K keyboard shortcut for Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        role,
        setRole,
        isLoggedIn,
        setIsLoggedIn,
        activeTab,
        setActiveTab,
        selectedProblemId,
        setSelectedProblemId,
        selectedSubmissionId,
        setSelectedSubmissionId,
        selectedContestId,
        setSelectedContestId,
        problems,
        addProblem,
        updateProblem,
        deleteProblem,
        submissions,
        addSubmission,
        solvedProblemIds,
        bookmarks,
        toggleBookmark,
        settings,
        updateSettings,
        theme,
        toggleTheme,
        setTheme,
        searchModalOpen,
        setSearchModalOpen,
        editProfileModalOpen,
        setEditProfileModalOpen,
        navigateToProblem,
        navigateToSubmission,
        navigateToContest,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
